"""proyecto URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from django.urls import path
from proyecto_app import views#importa la vista desde la applicacion
from modernrpc.views import RPCEntryPoint#importa un punto de entrada para los servicios

urlpatterns = [
    url(r'^horoscopo/$', views.principal, name='principal'),
    url(r'^muestra/$', views.adivinar, name='adivinar'),
    path('rpc/',RPCEntryPoint.as_view()),
    path('muestra/<int:id>',views.rpcadivinar,name='rpcadivinar'),
    url(r'^admin/', admin.site.urls),
    url('calcular_horoscopo/', views.get_suma, name='calculadora'),
    path('rpc/',RPCEntryPoint.as_view()),
    path('calculadora/<int:a>/<int:b>',views.rpcAdd,name='rpcAdd'),
    url(r'^afinidad/$', views.afinidad, name='afinidad'),
    path('rpc/',RPCEntryPoint.as_view()),
    path('afinidad/<int:id_1>/<int:id_2>',views.rpcafinidad,name='rpcafinidad'),
    url(r'^chino/$', views.chino, name='chino'),
    path('rpc/',RPCEntryPoint.as_view()),
    path('chino/<int:anho>',views.rpcchino,name='rpcchino'),


]
