from proyecto.settings import * #Se importa todo desde proyecto
#Se activa Debug mode para el desarrollo
# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True
#Configuracion de la base de datos
# Database
# https://docs.djangoproject.com/en/2.1/ref/settings/#databases
DATABASES = {
    'default': {
        'ENGINE': 'mysql_cymysql',
        'NAME': 'horoscopo',
        'USER': 'root',
        'PASSWORD': '',
        'HOST': 'localhost',
        'PORT': '3306',
    }
}
