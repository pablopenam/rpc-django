from django.shortcuts import render
from xmlrpc.client import ServerProxy
from django import forms
from .forms import sumaForm
from .forms import adivform
from .forms import afinform
from .models import Signo
from .forms import chinoform



def principal (request):
    return render(request,'index_horoscopo.html')
def rpcafinidad(resquest,id_1, id_2):
    cliente = ServerProxy('http://localhost:8000/rpc/')
    resultado = cliente.afinidad(id_1,id_2)
    return  render(resquest,'afinidad.html',{'resultado':resultado})
def afinidad (request):
    #se establece el metodo de respuesta
    if request.method == 'POST':
        #se crea un objeto de sumaForm
        afinidad = afinform(request.POST)
        #se verifica que el formulario sea valido
        if afinidad.is_valid():
            #obtiene los datos ingresados por el formulario
            data1 = afinidad.cleaned_data['id_1']
            data2 = afinidad.cleaned_data['id_2']
            #Transforma los datos a Flotante
            id_1=float('0' + data1)
            id_2=float('0' + data2)
            #Crea un objeto remoto
            cliente = ServerProxy('http://localhost:8000/rpc/')
            #obtiene el resultado de llamar al metodo adivinar
            resultado = cliente.afinidad(id_1,id_2)
            return render(request,'afinidad.html',{'form':afinidad,'resultado':resultado })
    else:
        afinidad = afinform()
    arg={'form':afinidad}
    return render(request,'afinidad.html',arg)

def rpcadivinar(resquest,id):
    cliente = ServerProxy('http://localhost:8000/rpc/')
    resultado = cliente.adivinar(id)
    return  render(resquest,'muestra.html',{'resultado':resultado})

def adivinar(request):
    #se establece el metodo de respuesta
    if request.method == 'POST':
        #se crea un objeto de sumaForm
        adivina = adivform(request.POST)
        #se verifica que el formulario sea valido
        if adivina.is_valid():
            #obtiene los datos ingresados por el formulario
            data1 = adivina.cleaned_data['id']
            #Transforma los datos a Flotante
            id=float('0' + data1)
            #Crea un objeto remoto
            cliente = ServerProxy('http://localhost:8000/rpc/')
            #obtiene el resultado de llamar al metodo adivinar
            resultado = cliente.adivinar(id)
            return render(request,'muestra.html',{'form':adivina,'resultado':resultado })
    else:
        adivina = adivform()
    arg={'form':adivina}
    return render(request,'muestra.html',arg)



#Llamada a procedimiento remoto, ejemplo simple
def rpcAdd(resquest,a,b):
    client = ServerProxy('http://localhost:8000/rpc/')
    result = client.add(a, b)
    return  render(resquest,'rpcAdd.html',{'result':result})
#vista para el formulario
def get_suma(request):
    #se establece el metodo de respuesta
    if request.method == 'POST':
        #se crea un objeto de sumaForm
        form = sumaForm(request.POST)
        #se verifica que el formulario sea valido
        if form.is_valid():
            #obtiene los datos ingresados por el formulario
            data1 = form.cleaned_data['a']
            data2 = form.cleaned_data['b']
            #Transforma los datos a Flotante
            a=float('0' + data1)
            b=float('0' + data2)
            #{'form':form,'mydata':data1}
            #Crea un objeto remoto
            client = ServerProxy('http://localhost:8000/rpc/')
            #obtiene el resultado de llamar al metodo add
            resulta = client.add(a, b)
            return render(request,'index.html',{'form':form,'resulta':resulta })
    else:
        form = sumaForm()
    arg={'form':form}
    return render(request,'index.html',arg)

def rpcchino(resquest,anho):
    cliente = ServerProxy('http://localhost:8000/rpc/')
    resultado = cliente.chino(anho)
    return  render(resquest,'h_chino.html',{'resultado':resultado})
def chino(request):
    #se establece el metodo de respuesta
    if request.method == 'POST':
        #se crea un objeto de sumaForm
        chino = chinoform(request.POST)
        #se verifica que el formulario sea valido
        if chino.is_valid():
            #obtiene los datos ingresados por el formulario
            data1 = chino.cleaned_data['anho']

            #Transforma los datos a Flotante
            anho=float('0' + data1)

            #Crea un objeto remoto
            cliente = ServerProxy('http://localhost:8000/rpc/')
            #obtiene el resultado de llamar al metodo adivinar
            resultado = cliente.chino(anho)
            return render(request,'h_chino.html',{'form':chino,'resultado':resultado })
    else:
        chino = chinoform()
    arg={'form':chino}
    return render(request,'h_chino.html',arg)
