from modernrpc.core import rpc_method
from xmlrpc.client import ServerProxy
from .models import Signo
from .models import Afinidad
from .models import SignoChino


@rpc_method
def add(a,b):
    if(a>=20 and b==1) or (a<=19 and b==2):
        #llamada a la funcion adivinar
        signo=adivinar(7)
        return signo
    elif(a>=20 and b==2) or(a<=20 and b==3):
        signo=adivinar(8)
        return signo
    elif(a>=21 and b==3) or(a<=20 and b==4):
        signo=adivinar(9)
        return signo
    elif(a>=21 and b==4) or(a<=20 and b==5):
        signo=adivinar(10)
        return signo
    elif(a>=21 and b==5) or(a<=21 and b==6):
        signo=adivinar(11)
        return signo
    elif(a>=22 and b==6) or(a<=22 and b==7):
        signo=adivinar(12)
        return signo
    elif(a>=23 and b==7) or(a<=23 and b==8):
        signo=adivinar(1)
        return signo
    elif(a>=24 and b==8) or(a<=23 and b==9):
        signo=adivinar(2)
        return signo
    elif(a>=24 and b==9) or(a<=22 and b==10):
        rsigno=adivinar(3)
        return signo
    elif(a>=23 and b==10) or(a<=22 and b==11):
        signo=adivinar(4)
        return signo
    elif(a>=23 and b==11) or(a<=21 and b==12):
        signo=adivinar(5)
        return signo
    elif(a>=22 and b==12) or(a<=19 and b==1):
        signo=adivinar(6)
        return signo

@rpc_method
def adivinar(id):
    obj = Signo.objects.all()
#for para recorrer la tabla signo
    for hor in obj:
        obj.id_signo      = hor.id_signo
        obj.nombre        = hor.nombre
        obj.personalidad  = hor.personalidad
        obj.color         = hor.color
        obj.elemento      = hor.elemento
        obj.simboliza     = hor.simboliza
        obj.semanal       = hor.semanal


#compara el id que se ingresa en el formulario con el id_signo que esta en la base de datos
        if id == obj.id_signo:
# retorna todos los atributos asociados al id_signo
            return hor
@rpc_method

def afinidad(id_1,id_2):
    obj=Afinidad.objects.all()
    for hor in obj:
        obj.id_afinidad = hor.id_afinidad
        obj.id_signo1 = hor.id_signo1
        obj.id_signo2 = hor.id_signo2
        obj.elementos = hor.elementos
        obj.analisis = hor.analisis

        if (id_1==obj.id_signo1 and id_2==obj.id_signo2) or (id_1==obj.id_signo2 and id_2==obj.id_signo1):
            return hor

@rpc_method

def chino(anho):
    obj=SignoChino.objects.all()
    for hor in obj:
        obj.nombre = hor.nombre
        obj.descripcion = hor.descripcion
        obj.planeta = hor.planeta
        obj.elemento = hor.elemento
        obj.anho = hor.anho
        obj.signo_equivalente = hor.signo_equivalente
        obj.personalidad = hor.personalidad
        obj.signo_compatible = hor.signo_compatible


        contador=obj.anho
        while anho >= contador:
            if anho == contador:
                return hor

            contador+=12
