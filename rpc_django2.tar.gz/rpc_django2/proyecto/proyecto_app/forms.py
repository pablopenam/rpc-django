from django import forms

class sumaForm(forms.Form):
    a=forms.CharField()
    b=forms.CharField()

class adivform(forms.Form):
    id=forms.CharField()

class afinform(forms.Form):
    id_1=forms.CharField()
    id_2=forms.CharField()
class chinoform(forms.Form):
    anho=forms.CharField()
